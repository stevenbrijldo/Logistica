- El archivo fonts.zip contiene las fuentes elegidas

- El archivo Flat-UI-master.zip contiene el template Flat-UI

- El manual de estilos est� incompleto pero basta para realizar los
  cambios necesarios al template.